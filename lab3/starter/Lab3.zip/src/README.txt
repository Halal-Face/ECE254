processes/
    - Run make clean
    - Rune make
    - Usage: ./produce.out <N> <B> <P> <C>
threads/
    - Run make clean
    - Rune make
    - Usage: ./produce.out <N> <B> <P> <C>