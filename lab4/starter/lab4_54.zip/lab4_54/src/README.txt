Run: make clean && make

To test External Fragmentation: ./main_test.out 

To test Allocation and Deallocation: ./main_test.out 1

Each testing mode tests both Best Fit and Worst Fit
